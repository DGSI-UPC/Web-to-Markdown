This domain is for use in illustrative examples in documents. You may use this
domain in literature without prior coordination or asking for permission.

More information...

